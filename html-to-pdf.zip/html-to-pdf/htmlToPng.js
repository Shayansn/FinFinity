const puppeteer = require('puppeteer');
const fs = require('fs').promises; // Properly import fs with promises for async operations

async function htmlToPNG() {
    const browser = await puppeteer.launch();
    const page = await browser.newPage();

    // Read HTML content from a file
    const content = await fs.readFile('goalTracker.html', 'utf8'); // Make sure to provide the correct path

    // Set the HTML content
    await page.setContent(content, {
        waitUntil: 'networkidle0' // Ensures all scripts are executed
    });

    // Define the area of the page to capture
    const clip = await page.evaluate(() => {
        return {
            x: 0,
            y: 0,
            width: document.documentElement.offsetWidth,
            height: document.documentElement.offsetHeight,
        };
    });

    // Capture the rendered content as a PNG image
    await page.screenshot({
        path: 'output.png',
        clip: clip
    });

    await browser.close();
    console.log('PNG image has been generated!');
}

htmlToPNG().catch(error => {
    console.error('Error:', error);
});
