const express = require('express');
const bodyParser = require('body-parser');
const path = require('path');
const app = express();
const port = 3000;

app.use(express.static('public'));
app.use(bodyParser.urlencoded({ extended: true }));

app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.post('/convert', (req, res) => {
    const type = req.body.type; // 'pdf', 'png', 'jpeg'
    console.log(`Converting to: ${type}`);
    res.send(`File converted to ${type} and ready to download.`);
});

app.listen(port, () => {
    console.log(`Server running at http://localhost:${port}/`);
});
