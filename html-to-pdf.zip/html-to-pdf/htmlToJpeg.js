const puppeteer = require('puppeteer');
const fs = require('fs').promises; // Use fs promises for async read

async function htmlToJPEG() {
    const browser = await puppeteer.launch();
    const page = await browser.newPage();

    // Read the HTML content from a file
    const content = await fs.readFile('goalTracker.html', 'utf8');

    // Set the HTML content in Puppeteer
    await page.setContent(content, {
        waitUntil: 'networkidle0' // Ensures all scripts are executed
    });

    // Define the viewport size if necessary
    await page.setViewport({ width: 1280, height: 800 });

    // Capture the rendered content as a JPEG image
    await page.screenshot({
        path: 'output.jpeg',
        type: 'jpeg',
        quality: 100 // JPEG quality from 0-100
    });

    await browser.close();
    console.log('JPEG image has been generated!');
}

htmlToJPEG().catch(error => {
    console.error('Error:', error);
});
