const puppeteer = require('puppeteer');
const fs = require('fs').promises; // Use promises for async read

async function htmlToPDF() {
    const browser = await puppeteer.launch();
    const page = await browser.newPage();

    // Read the HTML file
    const content = await fs.readFile('goalTracker.html', 'utf8'); 
    // Ensure the path and file name are correct

    // Set the content of the page
    await page.setContent(content, {
        waitUntil: 'networkidle0' // waits until all initial load JavaScript has executed
    });

    // Create a PDF from the page content
    await page.pdf({ path: 'output.pdf', format: 'A4' });

    await browser.close();
    console.log('PDF Generated!');
}

htmlToPDF().catch(error => {
    console.error('Error:', error);
});